#ifndef SCREEN_KMAPDEF_H
#define SCREEN_KMAPDEF_H

/* global variables */

extern char *kmapadef[];
extern char *kmapdef[];
extern char *kmapmdef[];

#endif /* SCREEN_KMAPDEF_H */
