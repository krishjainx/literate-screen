#define ORIGIN "GNU"
#define REV "5"
#define VERS "0"
#define PATCHLEVEL "1"
#define DATE "02-Jan-24" // SOME DATE
#define STATE ""
